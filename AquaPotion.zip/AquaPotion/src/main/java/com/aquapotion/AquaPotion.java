package com.aquapotion;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

public final class AquaPotion extends JavaPlugin {

    /** Запасні тексти, якщо ключ видалили з config.yml. */
    private static final Map<String, String> DEFAULT_MESSAGES = Map.of(
            "prefix", "<aqua>[AquaPotion]</aqua> ",
            "reload-success", "<prefix><green>Конфіг перезавантажено.</green> <gray>Зілля: <white><potion></white>, бризкаючі: <white><splash></white>, затримані: <white><lingering></white></gray>",
            "no-permission", "<prefix><red>У вас немає прав на цю команду.</red>",
            "usage", "<prefix><yellow>Використання: /<label> reload</yellow>",
            "invalid-stack-size", "<prefix><yellow>Некоректне значення <key>: <value>. Використано <default>.</yellow>"
    );

    private final MiniMessage mini = MiniMessage.miniMessage();
    private StackManager stackManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        stackManager = new StackManager(this);
        stackManager.load();

        var pm = getServer().getPluginManager();
        pm.registerEvents(new InventoryListener(this, stackManager), this);
        pm.registerEvents(new ItemListener(this, stackManager), this);
        pm.registerEvents(new BrewingStandListener(this, stackManager), this);

        PluginCommand cmd = getCommand("aquapotion");
        if (cmd != null) {
            ReloadCommand rc = new ReloadCommand(this);
            cmd.setExecutor(rc);
            cmd.setTabCompleter(rc);
        }

        // Якщо плагін підключили без рестарту — оновлюємо тих, хто вже онлайн.
        stackManager.refreshOnlinePlayers();
    }

    public void reloadAll() {
        reloadConfig();
        stackManager.load();
        stackManager.refreshOnlinePlayers();
    }

    public StackManager stacks() {
        return stackManager;
    }

    public Component message(String key, TagResolver... resolvers) {
        String prefix = getConfig().getString("messages.prefix", DEFAULT_MESSAGES.get("prefix"));
        String raw = getConfig().getString("messages." + key, DEFAULT_MESSAGES.getOrDefault(key, key));
        TagResolver all = TagResolver.builder()
                .resolvers(resolvers)
                .resolver(Placeholder.parsed("prefix", prefix))
                .build();
        return mini.deserialize(raw, all);
    }
}
