package com.aquapotion;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.BrewingStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BrewEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.inventory.BrewerInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * Варильна стійка.
 *
 * ПРОБЛЕМА: після того як зілля стали стакатися, у слот підставки (0–2) можна
 * "засунути" більше одного зілля (особливо хопером: у нього ліміт береться з
 * предмета = 16, а не зі слота = 1). Підставка очікує рівно 1 пляшку на слот.
 *
 * РІШЕННЯ (без дюпів — кількість предметів завжди зберігається):
 *  1. Shift-клік стака 2+ зіль з інвентаря: кладемо рівно по 1 у кожен вільний слот,
 *     залишок лишається в інвентарі гравця.
 *  2. Хопер/дропер: якщо вільних слотів немає — скасовуємо передачу (нічого не
 *     втрачається, хопер просто чекає); якщо є — дозволяємо, а наступного тіку
 *     "лишок" розкладається по вільних слотах.
 *  3. ЛКМ/ПКМ/цифри/drag: ванільний слот підставки і так має ліміт 1, а наш
 *     sanitize() наступного тіку — страховка, яка розкладає/повертає зайве.
 */
public final class BrewingStandListener implements Listener {

    private static final int FIRST_POTION_SLOT = 0;
    private static final int LAST_POTION_SLOT = 2;

    private final AquaPotion plugin;
    private final StackManager stacks;

    public BrewingStandListener(AquaPotion plugin, StackManager stacks) {
        this.plugin = plugin;
        this.stacks = stacks;
    }

    // ------------------------------------------------------------------ варіння

    /** Результат варіння отримує компонент → нові зілля стакаються зі старими. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBrew(BrewEvent e) {
        List<ItemStack> results = e.getResults();
        for (int i = 0; i < results.size(); i++) {
            ItemStack r = results.get(i);
            if (r == null || !stacks.isPotion(r.getType())) continue;
            ItemStack c = r.clone();
            if (!stacks.apply(c)) continue;
            try {
                results.set(i, c);
            } catch (UnsupportedOperationException ex) {
                stacks.apply(r); // запасний варіант: правимо на місці
            }
        }

        // Страховка: наступного тіку вирівнюємо вміст самої підставки.
        Location loc = e.getBlock().getLocation();
        Bukkit.getRegionScheduler().run(plugin, loc, t -> {
            if (e.getBlock().getState(false) instanceof BrewingStand bs) {
                stacks.normalize(bs.getInventory(), loc);
            }
        });
    }

    // ------------------------------------------------------------------ кліки гравця

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        Inventory top = e.getView().getTopInventory();
        if (!(top instanceof BrewerInventory brewer)) return;

        Inventory clicked = e.getClickedInventory();
        ItemStack current = e.getCurrentItem();

        // --- ШИФТ-КЛІК стака з інвентаря гравця в підставку ---
        if (e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY
                && clicked != null && clicked != top
                && current != null && stacks.isPotion(current.getType())
                && current.getAmount() > 1
                && countFreePotionSlots(brewer) > 0) {

            e.setCancelled(true); // ми самі акуратно перекладаємо предмети нижче

            int placed = 0;
            int amount = current.getAmount();
            for (int i = FIRST_POTION_SLOT; i <= LAST_POTION_SLOT && placed < amount; i++) {
                if (StackManager.isEmpty(brewer.getItem(i))) {
                    ItemStack one = current.clone();
                    one.setAmount(1);
                    stacks.apply(one);
                    brewer.setItem(i, one);
                    placed++;
                }
            }

            int remaining = amount - placed; // залишок лишається в інвентарі гравця
            ItemStack rest = null;
            if (remaining > 0) {
                rest = current.clone();
                rest.setAmount(remaining);
            }
            clicked.setItem(e.getSlot(), rest);
        }

        // Для всіх інших дій (ЛКМ, ПКМ, цифри, swap) — страховка наступного тіку.
        scheduleSanitize(player, brewer);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (!(e.getView().getTopInventory() instanceof BrewerInventory brewer)) return;
        // Drag по слотах підставки: ванільний код обмежує слот до 1, sanitize — страховка.
        scheduleSanitize(player, brewer);
    }

    // ------------------------------------------------------------------ хопери / дропери

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(InventoryMoveItemEvent e) {
        if (!(e.getDestination() instanceof BrewerInventory brewer)) return;
        if (!stacks.isPotion(e.getItem().getType())) return; // інгредієнти/паливо не чіпаємо

        int free = 0;
        int pending = 0; // "лишки", які ще не розкладені попередньою передачею
        for (int i = FIRST_POTION_SLOT; i <= LAST_POTION_SLOT; i++) {
            ItemStack s = brewer.getItem(i);
            if (StackManager.isEmpty(s)) free++;
            else if (stacks.isPotion(s.getType()) && s.getAmount() > 1) pending += s.getAmount() - 1;
        }

        if (free - pending <= 0) {
            // Місця немає. Хопер міг би влити зілля в зайнятий слот (бо ліміт предмета = 16).
            // Скасування безпечне: хопер сам поверне предмет у своє джерело.
            e.setCancelled(true);
            return;
        }

        Location loc = brewer.getLocation();
        if (loc != null) {
            Bukkit.getRegionScheduler().run(plugin, loc, t -> sanitize(brewer, null));
        }
    }

    // ------------------------------------------------------------------ sanitize

    private int countFreePotionSlots(BrewerInventory inv) {
        int free = 0;
        for (int i = FIRST_POTION_SLOT; i <= LAST_POTION_SLOT; i++) {
            if (StackManager.isEmpty(inv.getItem(i))) free++;
        }
        return free;
    }

    private void scheduleSanitize(Player player, BrewerInventory inv) {
        player.getScheduler().run(plugin, t -> sanitize(inv, player), null);
    }

    /**
     * Якщо в слоті підставки опинилося 2+ зіль: залишаємо 1, зайве розкладаємо по
     * вільних слотах підставки, далі — гравцеві (або на землю). Предмети не губляться.
     */
    private void sanitize(BrewerInventory inv, Player owner) {
        for (int i = FIRST_POTION_SLOT; i <= LAST_POTION_SLOT; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || !stacks.isPotion(s.getType()) || s.getAmount() <= 1) continue;

            int extra = s.getAmount() - 1;
            ItemStack one = s.clone();
            one.setAmount(1);
            inv.setItem(i, one);

            // 1) у вільні слоти підставки
            for (int j = FIRST_POTION_SLOT; j <= LAST_POTION_SLOT && extra > 0; j++) {
                if (StackManager.isEmpty(inv.getItem(j))) {
                    ItemStack p = s.clone();
                    p.setAmount(1);
                    inv.setItem(j, p);
                    extra--;
                }
            }

            // 2) що лишилось — гравцю, а що не влізло — на землю
            if (extra > 0) {
                ItemStack surplus = s.clone();
                surplus.setAmount(extra);
                Location drop = owner != null ? owner.getLocation() : inv.getLocation();
                Map<Integer, ItemStack> left = owner != null
                        ? owner.getInventory().addItem(surplus)
                        : Map.of(0, surplus);
                for (ItemStack l : left.values()) {
                    if (drop != null && drop.getWorld() != null) {
                        drop.getWorld().dropItemNaturally(drop, l);
                    }
                }
            }
        }
    }
}
