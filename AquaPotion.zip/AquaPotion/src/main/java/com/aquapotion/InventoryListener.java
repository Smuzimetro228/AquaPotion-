package com.aquapotion;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.MerchantInventory;

/**
 * Ледаче оновлення: інвентар гравця — при вході/відкритті, контейнери світу
 * (скрині, бочки, шалкери, хопери, діспенсери...) — лише коли їх відкривають.
 * Жодних обходів чанків.
 */
public final class InventoryListener implements Listener {

    private final AquaPotion plugin;
    private final StackManager stacks;

    public InventoryListener(AquaPotion plugin, StackManager stacks) {
        this.plugin = plugin;
        this.stacks = stacks;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        stacks.normalizePlayer(e.getPlayer());
    }

    @EventHandler
    public void onOpen(InventoryOpenEvent e) {
        Inventory top = e.getInventory();

        if (top instanceof MerchantInventory mi && mi.getMerchant() != null) {
            // Торговці: підміняємо результат угоди ДО того, як гравець його забере.
            stacks.normalizeMerchant(mi.getMerchant());
        } else if (stacks.isManaged(top.getType())) {
            stacks.normalize(top, top.getLocation());
        }

        if (e.getPlayer() instanceof Player p) {
            stacks.normalizePlayerInventory(p);
        }
    }

    /**
     * Страховка: якщо гравець взяв/тримає "старе" зілля без компонента (з чужого плагіна,
     * хоппера, команди /give тощо) — оновимо його інвентар наступного тіку.
     * Нічого не скасовуємо і не підміняємо в самій події.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (stacks.needsUpdate(e.getCurrentItem()) || stacks.needsUpdate(e.getCursor())) {
            p.getScheduler().run(plugin, t -> stacks.normalizePlayerInventory(p), null);
        }
    }
}
