package com.aquapotion;

import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Всі місця, де зілля з'являється "з повітря": дроп, підбір, лут, крафт, торгівля.
 *
 * Навмисно НЕ чіпаємо PlayerItemConsumeEvent та BlockDispenseEvent:
 *  - випивання/кидок зменшує стак на 1 нативно, пляшка повертається ванільним кодом;
 *  - під час BlockDispenseEvent сервер тримає посилання на стак у діспенсері, і
 *    підміна предмета в цей момент призвела б до дюпу.
 */
public final class ItemListener implements Listener {

    private final AquaPotion plugin;
    private final StackManager stacks;

    public ItemListener(AquaPotion plugin, StackManager stacks) {
        this.plugin = plugin;
        this.stacks = stacks;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent e) {
        Item item = e.getEntity();
        ItemStack s = item.getItemStack();
        if (!stacks.isPotion(s.getType())) return;
        ItemStack copy = s.clone();
        if (stacks.apply(copy)) item.setItemStack(copy);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        Item item = e.getItem();
        ItemStack s = item.getItemStack();
        if (!stacks.isPotion(s.getType())) return;

        ItemStack copy = s.clone();
        if (stacks.apply(copy)) item.setItemStack(copy);

        // Страховка: після підбору вирівнюємо інвентар (якщо стак уже був "старим").
        if (e.getEntity() instanceof Player p) {
            p.getScheduler().run(plugin, t -> stacks.normalizePlayerInventory(p), null);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onLoot(LootGenerateEvent e) {
        List<ItemStack> out = new ArrayList<>(e.getLoot().size());
        boolean changed = false;
        for (ItemStack s : e.getLoot()) {
            if (s != null && stacks.isPotion(s.getType())) {
                ItemStack c = s.clone();
                if (stacks.apply(c)) {
                    out.add(c);
                    changed = true;
                    continue;
                }
            }
            out.add(s);
        }
        if (changed) e.setLoot(out);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        ItemStack result = e.getInventory().getResult();
        if (result == null || !stacks.isPotion(result.getType())) return;
        ItemStack c = result.clone();
        if (stacks.apply(c)) e.getInventory().setResult(c);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTrade(VillagerAcquireTradeEvent e) {
        e.setRecipe(stacks.normalizeRecipe(e.getRecipe()));
    }
}
