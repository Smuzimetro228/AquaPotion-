package com.aquapotion;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.List;

public final class ReloadCommand implements TabExecutor {

    private static final String PERMISSION = "aquapotion.reload";
    private final AquaPotion plugin;

    public ReloadCommand(AquaPotion plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission(PERMISSION)) {
                sender.sendMessage(plugin.message("no-permission"));
                return true;
            }
            plugin.reloadAll();
            StackManager sm = plugin.stacks();
            sender.sendMessage(plugin.message("reload-success",
                    Placeholder.unparsed("potion", String.valueOf(sm.sizeFor(Material.POTION))),
                    Placeholder.unparsed("splash", String.valueOf(sm.sizeFor(Material.SPLASH_POTION))),
                    Placeholder.unparsed("lingering", String.valueOf(sm.sizeFor(Material.LINGERING_POTION)))));
            return true;
        }
        sender.sendMessage(plugin.message("usage", Placeholder.unparsed("label", label)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission(PERMISSION)) {
            return "reload".startsWith(args[0].toLowerCase()) ? List.of("reload") : List.of();
        }
        return List.of();
    }
}
