package com.aquapotion;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Merchant;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Уся логіка компонента max_stack_size.
 *
 * Принцип: ми НІКОЛИ не склеюємо/розбиваємо стаки в подіях. Ми лише гарантуємо,
 * що у всіх зіль одного типу однаковий компонент max_stack_size — далі стакування,
 * випивання, кидок, хопери, шалкери тощо обробляє сам ванільний рушій.
 */
public final class StackManager {

    public static final int DEFAULT_SIZE = 16;
    public static final int MIN_SIZE = 1;
    public static final int MAX_SIZE = 99;

    /** Типи інвентарів, які ми оновлюємо ледачо — в момент відкриття. */
    private static final Set<InventoryType> MANAGED = EnumSet.of(
            InventoryType.CHEST, InventoryType.ENDER_CHEST, InventoryType.BARREL,
            InventoryType.SHULKER_BOX, InventoryType.HOPPER, InventoryType.DISPENSER,
            InventoryType.DROPPER, InventoryType.BREWING);

    private final AquaPotion plugin;
    private volatile int potionSize = DEFAULT_SIZE;
    private volatile int splashSize = DEFAULT_SIZE;
    private volatile int lingeringSize = DEFAULT_SIZE;

    public StackManager(AquaPotion plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ config

    public void load() {
        FileConfiguration cfg = plugin.getConfig();
        potionSize = read(cfg, "potion");
        splashSize = read(cfg, "splash-potion");
        lingeringSize = read(cfg, "lingering-potion");
    }

    private int read(FileConfiguration cfg, String key) {
        String path = "stack-sizes." + key;
        Object raw = cfg.get(path);
        if (raw instanceof Number n) {
            double d = n.doubleValue();
            if (d == Math.rint(d) && d >= MIN_SIZE && d <= MAX_SIZE) {
                return (int) d;
            }
        }
        plugin.getComponentLogger().warn(plugin.message("invalid-stack-size",
                Placeholder.unparsed("key", path),
                Placeholder.unparsed("value", String.valueOf(raw)),
                Placeholder.unparsed("default", String.valueOf(DEFAULT_SIZE))));
        return DEFAULT_SIZE;
    }

    // ------------------------------------------------------------------ helpers

    public boolean isPotion(Material m) {
        return m == Material.POTION || m == Material.SPLASH_POTION || m == Material.LINGERING_POTION;
    }

    public int sizeFor(Material m) {
        return switch (m) {
            case POTION -> potionSize;
            case SPLASH_POTION -> splashSize;
            case LINGERING_POTION -> lingeringSize;
            default -> 1;
        };
    }

    public boolean isManaged(InventoryType type) {
        return MANAGED.contains(type);
    }

    public static boolean isEmpty(ItemStack s) {
        return s == null || s.getType().isAir();
    }

    /** Чи потребує предмет оновлення компонента. */
    public boolean needsUpdate(ItemStack s) {
        if (s == null || !isPotion(s.getType())) return false;
        ItemMeta meta = s.getItemMeta();
        if (meta == null) return false;
        int target = sizeFor(s.getType());
        if (target == 1) return meta.hasMaxStackSize(); // 1 == ванільне значення, компонент не потрібен
        return !(meta.hasMaxStackSize() && meta.getMaxStackSize() == target);
    }

    /**
     * Виставляє компонент max_stack_size відповідно до конфігу (змінює переданий стак).
     * Якщо ліміт = 1 (ванільний) — компонент прибирається, щоб усі зілля були однакові.
     *
     * @return true, якщо стак змінено
     */
    public boolean apply(ItemStack s) {
        if (s == null || !isPotion(s.getType())) return false;
        ItemMeta meta = s.getItemMeta();
        if (meta == null) return false;
        int target = sizeFor(s.getType());
        if (target == 1) {
            if (!meta.hasMaxStackSize()) return false;
            meta.setMaxStackSize(null);
        } else {
            if (meta.hasMaxStackSize() && meta.getMaxStackSize() == target) return false;
            meta.setMaxStackSize(target);
        }
        s.setItemMeta(meta);
        return true;
    }

    // ------------------------------------------------------------------ inventories

    /**
     * Оновлює всі зілля в інвентарі. Якщо стак більший за новий ліміт — надлишок
     * НЕ видаляється: він розкладається по вільних слотах, а якщо місця немає,
     * падає на землю (dropAt). Якщо кинути нікуди — надлишок залишається в слоті
     * (ванільний рушій нормально працює з "переповненим" стаком).
     */
    public void normalize(Inventory inv, Location dropAt) {
        if (inv == null) return;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack s = contents[i];
            if (s == null || !isPotion(s.getType())) continue;

            boolean changed = apply(s);
            int max = sizeFor(s.getType());

            if (s.getAmount() > max) {
                // --- ОБХІД "РОЗСТАКУВАННЯ": лімітом зменшили, а в слоті більше, ніж можна ---
                int extra = s.getAmount() - max;
                ItemStack kept = s.clone();
                kept.setAmount(max);
                inv.setItem(i, kept); // спочатку фіксуємо слот, щоб addItem не влив надлишок назад

                ItemStack overflow = s.clone();
                overflow.setAmount(extra);
                Map<Integer, ItemStack> left = inv.addItem(overflow);
                for (ItemStack l : left.values()) {
                    if (dropAt != null && dropAt.getWorld() != null) {
                        dropAt.getWorld().dropItemNaturally(dropAt, l);
                    } else {
                        ItemStack cur = inv.getItem(i);
                        if (cur != null) {
                            cur.setAmount(cur.getAmount() + l.getAmount());
                            inv.setItem(i, cur);
                        }
                    }
                }
                changed = false; // слот уже записано
            }
            if (changed) inv.setItem(i, s);
        }
    }

    /** Інвентар гравця + предмет на курсорі. */
    public void normalizePlayerInventory(Player p) {
        normalize(p.getInventory(), p.getLocation());
        ItemStack cursor = p.getItemOnCursor();
        if (apply(cursor)) p.setItemOnCursor(cursor);
    }

    /** Інвентар гравця + ендер-скриня + курсор. */
    public void normalizePlayer(Player p) {
        normalizePlayerInventory(p);
        normalize(p.getEnderChest(), p.getLocation());
    }

    private void refreshPlayer(Player p) {
        normalizePlayer(p);
        Inventory top = p.getOpenInventory().getTopInventory();
        if (isManaged(top.getType())) normalize(top, top.getLocation());
    }

    /** Після reload: оновлюємо онлайн-гравців (на їхньому потоці, наступного тіку). */
    public void refreshOnlinePlayers() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.getScheduler().run(plugin, task -> refreshPlayer(p), null);
        }
    }

    // ------------------------------------------------------------------ trades

    public void normalizeMerchant(Merchant merchant) {
        List<MerchantRecipe> in = merchant.getRecipes();
        List<MerchantRecipe> out = new ArrayList<>(in.size());
        boolean changed = false;
        for (MerchantRecipe r : in) {
            MerchantRecipe n = normalizeRecipe(r);
            if (n != r) changed = true;
            out.add(n);
        }
        if (changed) merchant.setRecipes(out);
    }

    public MerchantRecipe normalizeRecipe(MerchantRecipe r) {
        ItemStack result = r.getResult().clone();
        if (!isPotion(result.getType()) || !apply(result)) return r;
        MerchantRecipe n = new MerchantRecipe(result, r.getUses(), r.getMaxUses(),
                r.hasExperienceReward(), r.getVillagerExperience(), r.getPriceMultiplier(),
                r.getDemand(), r.getSpecialPrice());
        n.setIgnoreDiscounts(r.shouldIgnoreDiscounts());
        n.setIngredients(r.getIngredients());
        return n;
    }
}
